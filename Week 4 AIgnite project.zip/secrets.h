#pragma once

//wifi setup
#define WIFI_SSID      "Wokwi-GUEST"   
#define WIFI_PASSWORD  ""              

//gemini setup
#define API_KEY "AIzaSyBsF9A2PjKh7__tIM8Csh-I3fRFAJfwlSE"