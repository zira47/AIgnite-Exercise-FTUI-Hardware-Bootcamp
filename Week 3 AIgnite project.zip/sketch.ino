
#define BLYNK_TEMPLATE_ID "TMPL6pVOuuTDD"
#define BLYNK_TEMPLATE_NAME "Week 3 AIgnite project"
#define BLYNK_AUTH_TOKEN "YmIPWVhaUnDPUFbAp0IH1b4hgcqLylm0"

#include <WiFi.h>
#include <WiFiClient.h>
#include <BlynkSimpleEsp32.h>

char auth[] = BLYNK_AUTH_TOKEN;
char ssid[] = "Wokwi-GUEST";
char pass[] = "";

int pin_LED = 17;

BLYNK_WRITE(V0) {
  int pinValue = param.asInt();
  digitalWrite(pin_LED, pinValue);

  Serial.print("LED dari blynk: ");
  Serial.println(pinValue ? "ON" : "OFF");
}


void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);


  pinMode(pin_LED, OUTPUT);
  digitalWrite(pin_LED, LOW);

  Blynk.begin(auth, ssid, pass);
}

void loop() {
  // put your main code here, to run repeatedly:
  Blynk.run();
}
