String input;
int pin = 17 ;

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  Serial.println("Hello, ESP32!");

  pinMode(pin, OUTPUT);
}

void loop() {
  // put your main code here, to run repeatedly:
  Serial.print("Masukkan perintah di sini: ");
  while (!Serial.available());
  input = Serial.readStringUntil('\n');
  Serial.println(input);

  if (input == "nyalakan") {
    digitalWrite(pin, HIGH);
  }
  else if (input == "matikan") {
    digitalWrite(pin, LOW);
  }
  else {
    Serial.println("Input tidak valid. Coba \"nyalakan\" atau \"matikan\"");
  }


  delay(10); // this speeds up the simulation
}
